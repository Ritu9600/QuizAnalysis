import React from 'react';

function Solution() {
	return <div></div>;
}

export default Solution;
