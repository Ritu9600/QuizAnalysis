import React from "react";
import styled from "styled-components";
import './Comparison.css';
const weakConceptsData = [
  {
    topic: "Gravity",
    concepts: [
      "The pssdent act dss passfd in tdfe ferear .......................",
      "The pssdent acdstcd dss padsdssfd insdsd tdasasfe faweweerear ",
      "5th wiasu hisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doi dosdjos osd dos",
    ],
  },
  {
    topic: "Gravity",
    concepts: [
      "The pssdent act dss passfd in tdfe ferear .......................",
      "The pssdent acdstcd dss padsdssfd insdsd tdasasfe faweweerear ",
      "5th wiasu hisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doi dosdjos osd dos",
    ],
  },
  {
    topic: "Gravity",
    concepts: [
      "The pssdent act dss passfd in tdfe ferear .......................",
      "The pssdent acdstcd dss padsdssfd insdsd tdasasfe faweweerear ",
      "5th wiasu hisdiuas idu asui dui asow nld oasjdo iosd dos jdcsid odincos doi dosdjos osd dos",
    ],
  },
];

function WeakConcepts() {
  return (
    <WeakConceptContainer>
      <Header>
        <div className="number">Weak Concepts</div>
      </Header>
      <Concept>
        {weakConceptsData.map((data) => (
          <>
            <Topic>{data.topic}</Topic>
            {data.concepts.map((concept) => (
              <Description>{concept}</Description>
            ))}
          </>
        ))}
      </Concept>
    </WeakConceptContainer>
  );
}

export default WeakConcepts;

const WeakConceptContainer = styled.div`
  width: 100%;
  overflow: auto;
  font-size: 3vh;
`;

const Header = styled.div`
  border-bottom: 1px solid #1bbc9b;
  color: #1bbc9b;
  font-family: Inter;
  font-style: normal;
  padding-left:2%;
  padding-top: 3%;
  font-weight: 600;
  font-size: 22px;
`;

const Concept = styled.div`
  width: 100%;
  padding: 12px 16px;
  overflow-y: auto;
`;

const Topic = styled.div`
width: 100%;
padding: 10px 16px;
font-weight: 700;
font-size:18px;
`;

const Description = styled.div`
width: 100%;
padding: 0.3%;
padding-left:1.2%;
font-size: 13px;
font-weight:500;
`;
