import React from 'react';
import Quiz from '../../pages/Quiz';

function Solution() {
	return (<div>
		<Quiz/>
	</div>
	);
}

export default Solution;
