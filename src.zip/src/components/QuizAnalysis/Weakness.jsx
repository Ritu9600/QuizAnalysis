import React from "react";
import styled from "styled-components";
import Paper from "@mui/material/Paper";
import Card1 from "./Card";
import { makeStyles } from "@material-ui/core/styles";
import WeakConcepts from "./WeakConcepts";
import WeaknessGraph from "./WeaknessGraph";
import { Card, Row,  Col } from "reactstrap";
import "./Comparison.css";

// import Dashbar from "./DashBar";

const useStyles = makeStyles((theme) => ({
  paper: {
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const Item = styled(Paper)(() => ({
  textAlign: "center",
}));

function Weakness() {
  return (
    <Wrapper>
			<Row>
        <Col sm="8">
          <Card  className="card5">
          <WeaknessGraph  className="graph1"/>
          </Card>
        </Col>
        <Col sm="4">
          <Card className="card6" id='box'>
          <Card1 />
          </Card>
        </Col>
       </Row>
	   <Row className="comparitive">
     <WeakConceptsContainer>
          <WeakConcepts />
        </WeakConceptsContainer>
	 </Row>
		</Wrapper>
		
   
  );
}

// const section = {
//   height: "100%",
//   paddingTop: 5,
//   backgroundColor: "#fff",
// };

// function Weakness() {
//   return (
//     <Box sx={{ width: "100%" }}>
//       <Grid
//         container
//         rowSpacing={1}
//         columnSpacing={{ xs: 1, sm: 2, md: 3 }}
//         alignItems="baseline"
//         justifyContent="stretch"
//       >
//         <Grid item xs={7}>
//           <WeaknessGraph />
//         </Grid>
//         <Grid item xs={5}>
//           <div style={section}>
//             <Card />
//           </div>
//         </Grid>
//         <Grid item xs>
//           <div style={section}>
//             <Card />
//           </div>
//         </Grid>
//       </Grid>
//     </Box>
//   );
// }

export default Weakness;

const Wrapper = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  flex: 1;
`;

const RowOne = styled.div`
  display: flex;
  flex: 1;
`;

const RowTwo = styled.div`
  display: flex;
  flex: 1;
  overflow-y: auto;
`;

const WeaknessGraphContainer = styled.div`
  width: 60%;
  flex-grow: 1;
  // flex-shrink: 0;
  margin: 10px;
`;

const CardContainer = styled.div`
  width: 40%;
  flex-grow: 1;
  margin: 10px;
`;

const WeakConceptsContainer = styled.div`
  flex-grow: 1;
  margin: 10px;
`;
