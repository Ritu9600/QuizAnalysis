const reviewData = [
    {
      id: 1,
      name: "Beyonce",
      imgURL:
        "https://blackhistorywall.files.wordpress.com/2010/02/picture-device-independent-bitmap-119.jpg",
        detail: "hello 1500s, when an unknown printer took a galley of type and scrambled it to make",
        rating: 5,
        date: "13/03/2022"
    },
    {
      id: 2,
      name: "Jack Bauer",
      imgURL:
        "https://pbs.twimg.com/profile_images/625247595825246208/X3XLea04_400x400.jpg",
      detail: "hello 1500s, when an unknown printer took a galley of type and scrambled it to make",
      rating: 4.5,
      date: "13/03/2022"
    },
    {
      id: 3,
      name: "Chuck Norris",
      imgURL:
        "https://i.pinimg.com/originals/e3/94/47/e39447de921955826b1e498ccf9a39af.png",
        detail: "hello 1500s, when an unknown printer took a galley of type and scrambled it to make",
        rating: 4,
      date: "13/03/2022"
    }
  ];
  
  export default reviewData;