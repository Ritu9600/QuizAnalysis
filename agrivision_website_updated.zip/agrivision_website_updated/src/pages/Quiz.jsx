import Layout from "../components/Quiz/Layout";

function Quiz() {
  return (
    <>
      <Layout />
    </>
  );
}

export default Quiz;
