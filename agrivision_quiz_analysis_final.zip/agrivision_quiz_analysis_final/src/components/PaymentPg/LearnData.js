const LearnData=[
    "Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia",
    "If you are going to use a passage of Lorem Ipsum, you need to be ",
    "The standard chunk of Lorem Ipsum used since the 1500s is reproduced"
];

export default LearnData;