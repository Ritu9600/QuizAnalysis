import { useState, useEffect } from "react";
import styled from "styled-components";
import Header from "./Header";
import Main from "./Main";
//functionality demo
import data from "./dummy-question-data";
import Overview from "./Overview";
import Solution from "./Solution";
import Weakness from "./Weakness";
import Comparison from "./Comparison";

const numOfPhysicsQues = data.physics.length;
const numOfChemistryQues = data.chemistry.length;
const addSomeFields = (quesArray) => {
  let newData = quesArray.map((question) => ({
    ...question,
    status: "not-visited",
    answered: null,
  }));
  return newData;
};

const Layout = () => {
  const [activeSection, setActiveSection] = useState({
    overview: true,
    solution: false,
    weakness: false,
    comparison: false,
  });

  return (
    <Wrapper>
      <Header />
      <Container>
        <Main activeSection={activeSection} setActiveSection={setActiveSection} />

        <Tabs>
          {activeSection.overview ? <Overview /> : null}
          {activeSection.solution ? <Solution /> : null}
          {activeSection.weakness ? <Weakness /> : null}
          {activeSection.comparison ? <Comparison /> : null}
        </Tabs>
      </Container>
    </Wrapper>
  );
};

const Container = styled.div`
  height: calc(100% - 62px);
  width: 100%;
  // display: grid;
  // grid-template-columns: 2.5fr 1fr;
  display: flex;
  flex-direction: column;
  position: relative;
`;
const Wrapper = styled.div`
  width: 100%;
  height: 100vh;
`;

const Tabs = styled.div`
  width: 100%;
  height: 100%;
`;
export default Layout;
